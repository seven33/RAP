var shuffleSequence = seq("consent", "task explanation", "catch", "description", "habituation", "trial", "end", "send", "exit");
PennController.ResetPrefix(null);

PennController.AddHost("https://s3.us-east-2.amazonaws.com/rap2v1/");

var items = [
    // The item labeled 'send' is the special __SendResults__ item
    ["send", "__SendResults__", {}]
    ,
    
    // The exit page
    ["exit", "PennController", PennController(
        newHtml("exit", "exit.html")
            .print()
        ,
        // A dummy timer we never launch in order to stay on page forever
        newTimer("dummy", 10)
            .wait() // This will wait forever
    )]
    ,
    ["consent", "PennController", PennController(
        newHtml("consent form", "consent.html")
            .print()
        ,
        newButton("consent button", "I am in a quiet room and I consent to participate in this experiment.")
            .print()
            .wait()
    )]
    ,
    ["task explanation", "PennController", PennController(
        newHtml("task info", "task_intro.html")
            .print()
        ,
        newButton("start", "Continue")
            .print()
            .wait()
    )]
    ,
    ["catch", "PennController", PennController(
        image.defaults.settings.size(200, 200)
        ,
        canvas.defaults.settings.center()
        ,
        text.defaults
            .settings.center()
        ,
        // IMAGES
        newImage("target", "bed.png")
        ,
        newImage("competitor", "bed.png")
        ,
        newImage("f_arrow", "f_arrow.png")
        ,
        newImage("f_arrow2", "f_arrow.png")
        ,
        newImage("j_arrow", "j_arrow.png")
        ,
        newImage("white", "ffffff.png")
        ,
        
        newText("prompt", "Listen to the animal hiding under each bed (indicated by an arrow). Once you've heard both animals, <b>select the DOG</b> by pressing the corresponding key.")
            .print()
        ,
        newText("press a key", "Press any key to continue.")
            .settings.color("red")
            .print()
        ,
        newKey("any", "")
            .wait()
        ,
        getText("press a key")
            .settings.color("white") // "Remove" the keypress instruction from screen
            .print()
        ,
        newCanvas("canvas", 450, 450)
            .settings.add(  0, 0, getImage("target"))
            .settings.add(250, 0, getImage("competitor"))
            .print()
        ,
        newTimer("familiarization", 500)
            .start() // We start the timer right away
            .wait() // And we wait for it to finish before proceeding
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow"))
            .print()
        ,
        newAudio("dog", "dog.mp3")
            .play()
            .wait()
        ,
        newTimer("break_btwn_sent", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("white"))
            .settings.add(250, 250, getImage("j_arrow"))
            .print()
        ,
        newAudio("cat", "cat.mp3")
            .play()
            .wait()
        ,
        newTimer("timer", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow2"))
            .print()
        ,
        newText("instruction", "\n\nPress the key corresponding to the bed under which the DOG is hiding.")
            .print()
        ,
        newSelector("catch1")
            .settings.add(getImage("target"), getImage("competitor"))
            .settings.keys(         "F"   ,           "J"   )
        ,
        getSelector("catch1")
            .wait("first")
            .settings.log()
            
    )]
    ,
    ["catch", "PennController", PennController(
        image.defaults.settings.size(200, 200)
        ,
        canvas.defaults.settings.center()
        ,
        text.defaults
            .settings.center()
        ,
        // IMAGES
        newImage("competitor", "bush.png")
        ,
        newImage("target", "bush.png")
        ,
        newImage("f_arrow", "f_arrow.png")
        ,
        newImage("f_arrow2", "f_arrow.png")
        ,
        newImage("j_arrow", "j_arrow.png")
        ,
        newImage("white", "ffffff.png")
        ,
        
        newText("prompt", "Listen to the animal hiding in each bush (indicated by an arrow). Once you've heard both animals, <b>select the ROOSTER</b> by pressing the corresponding key.")
            .print()
        ,
        newText("press a key", "Press any key to continue.")
            .settings.color("red")
            .print()
        ,
        newKey("any", "")
            .wait()
        ,
        getText("press a key")
            .settings.color("white") // "Remove" the keypress instruction from screen
            .print()
        ,
        newCanvas("canvas", 450, 450)
            .settings.add(  0, 0, getImage("competitor"))
            .settings.add(250, 0, getImage("target"))
            .print()
        ,
        newTimer("familiarization", 500)
            .start() // We start the timer right away
            .wait() // And we wait for it to finish before proceeding
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow"))
            .print()
        ,
        newAudio("bird", "bird.mp3")
            .play()
            .wait()
        ,
        newTimer("break_btwn_sent", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("white"))
            .settings.add(250, 250, getImage("j_arrow"))
            .print()
        ,
        newAudio("rooster", "rooster.mp3")
            .play()
            .wait()
        ,
        newTimer("timer", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow2"))
            .print()
        ,
        newText("instruction", "\n\nPress the key corresponding to the barn where the ROOSTER is hiding.")
            .print()
        ,
        newSelector("catch2")
            .settings.add(getImage("competitor"), getImage("target"))
            .settings.keys(          "F"   ,            "J"   )
        ,
        getSelector("catch2")
            .wait("first")
            .settings.log()
            
    )]
    ,
    ["catch", "PennController", PennController(
        image.defaults.settings.size(200, 200)
        ,
        canvas.defaults.settings.center()
        ,
        text.defaults
            .settings.center()
        ,
        // IMAGES
        newImage("target", "barn.png")
        ,
        newImage("competitor", "barn.png")
        ,
        newImage("f_arrow", "f_arrow.png")
        ,
        newImage("f_arrow2", "f_arrow.png")
        ,
        newImage("j_arrow", "j_arrow.png")
        ,
        newImage("white", "ffffff.png")
        ,
        
        newText("prompt", "Listen to the animal hiding in each barn (indicated by an arrow). Once you've heard both animals, <b>select the HORSE</b> by pressing the corresponding key.")
            .print()
        ,
        newText("press a key", "Press any key to continue.")
            .settings.color("red")
            .print()
        ,
        newKey("any", "")
            .wait()
        ,
        getText("press a key")
            .settings.color("white") // "Remove" the keypress instruction from screen
            .print()
        ,
        newCanvas("canvas", 450, 450)
            .settings.add(  0, 0, getImage("target"))
            .settings.add(250, 0, getImage("competitor"))
            .print()
        ,
        newTimer("familiarization", 500)
            .start() // We start the timer right away
            .wait() // And we wait for it to finish before proceeding
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow"))
            .print()
        ,
        newAudio("horse", "horse.mp3")
            .play()
            .wait()
        ,
        newTimer("break_btwn_sent", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("white"))
            .settings.add(250, 250, getImage("j_arrow"))
            .print()
        ,
        newAudio("pig", "pig.mp3")
            .play()
            .wait()
        ,
        newTimer("timer", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow2"))
            .print()
        ,
        newText("instruction", "\n\nPress the key corresponding to the barn where the HORSE is hiding.")
            .print()
        ,
        newSelector("catch3")
            .settings.add(getImage("target"), getImage("competitor"))
            .settings.keys(          "F"   ,            "J"   )
        ,
        getSelector("catch3")
            .wait("first")
            .settings.log()
            
    )]
    ,
    ["description", "PennController", PennController(
        newHtml("background info", "backstory.html")
            .print()
        ,
        newButton("start", "Click here to begin audio.")
            .print()
            .wait()
    )]
    ,
    ["habituation", "PennController", PennController(
        text.defaults
            .settings.center()
        ,
        newText("instruct", "Listen closely to Bella's family song.")
            .settings.bold()
            .print()
        ,
        newText("instruct2", "<p>The song will last for approximately 2 minutes. Please listen to the entire thing.</p>")
            .print()
        ,
        newImage("scene", "scene.gif")
            .settings.size(400, 300)
            .settings.center()
            .print()
        ,
        newAudio("ABA habituation", "aba_hab.wav")
            .play()
            .wait()
        ,
        newText("space", "Click the button below to continue.")
            .settings.color("white")
            .print()
        ,
        newButton("End", "Click to continue.")
            .settings.center()
            .print()
            .wait()
    )]
    ,
    // TRIAL 1: rabbit1 = fewofe
    ["trial", "PennController", PennController(
        image.defaults.settings.size(200, 200)
        ,
        // IMAGES
        newImage("target", "rabbit_1.png")
        ,
        newImage("competitor", "rabbit_1.png")
        ,
        newImage("f_arrow", "f_arrow.png")
        ,
        newImage("f_arrow2", "f_arrow.png")
        ,
        newImage("j_arrow", "j_arrow.png")
        ,
        newImage("white", "ffffff.png")
        ,
        
        newText("prompt", "Listen to the song of each bunny (indicated by an arrow). Once you've heard both, <b>select Bella's mother</b> by pressing the corresponding key.")
            .print()
        ,
        newText("press a key", "Press any key to continue.")
            .settings.color("red")
            .print()
        ,
        newKey("any", "")
            .wait()
        ,
        getText("press a key")
            .settings.color("white") // "Remove" the keypress instruction from screen
            .print()
        ,
        newCanvas("canvas", 450, 450)
            .settings.add(  0, 0, getImage("target"))
            .settings.add(250, 0, getImage("competitor"))
            .print()
        ,
        newTimer("familiarization", 500)
            .start() // We start the timer right away
            .wait() // And we wait for it to finish before proceeding
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow"))
            .print()
        ,
        newAudio("fewofe", "fewofe.wav")
            .play()
            .wait()
        ,
        newTimer("break_btwn_sent", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("white"))
            .settings.add(250, 250, getImage("j_arrow"))
            .print()
        ,
        newAudio("fewowo", "fewowo.wav")
            .play()
            .wait()
        ,
        newTimer("timer", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow2"))
            .print()
        ,
        newText("instruction", "\n\nPress the key corresponding to the rabbit that is part of Bella's family.")
            .print()
        ,
        newSelector("trial1")
            .settings.add(getImage("target"), getImage("competitor"))
            .settings.keys(            "F"   ,              "J"   )
        ,
        getSelector("trial1")
            .wait("first")
            .settings.log()
            
    )]
    ,
    // TRIAL 2: rabbit2 = kodeko
    ["trial", "PennController", PennController(
        image.defaults.settings.size(200, 200)
        ,
        // IMAGES
        newImage("competitor", "rabbit_2.png")
        ,
        newImage("target", "rabbit_2.png")
        ,
        newImage("f_arrow", "f_arrow.png")
        ,
        newImage("f_arrow2", "f_arrow.png")
        ,
        newImage("j_arrow", "j_arrow.png")
        ,
        newImage("white", "ffffff.png")
        ,
        
        newText("prompt", "Listen to the song of each bunny (indicated by an arrow). Once you've heard both, <b>select Bella's father</b> by pressing the corresponding key.")
            .print()
        ,
        newText("press a key", "Press any key to continue.")
            .settings.color("red")
            .print()
        ,
        newKey("any", "")
            .wait()
        ,
        getText("press a key")
            .settings.color("white") // "Remove" the keypress instruction from screen
            .print()
        ,
        newCanvas("canvas", 450, 450)
            .settings.add(  0, 0, getImage("competitor"))
            .settings.add(250, 0, getImage("target"))
            .print()
        ,
        newTimer("familiarization", 500)
            .start() // We start the timer right away
            .wait() // And we wait for it to finish before proceeding
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow"))
            .print()
        ,
        newAudio("kodede", "kodede.wav")
            .play()
            .wait()
        ,
        newTimer("break_btwn_sent", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("white"))
            .settings.add(250, 250, getImage("j_arrow"))
            .print()
        ,
        newAudio("kodeko", "kodeko.wav")
            .play()
            .wait()
        ,
        newTimer("timer", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow2"))
            .print()
        ,
        newText("instruction", "\n\nPress the key corresponding to the rabbit that is part of Bella's family.")
            .print()
        ,
        newSelector("trial2")
            .settings.add(getImage("competitor"), getImage("target"))
            .settings.keys(            "F"   ,              "J"   )
        ,
        getSelector("trial2")
            .wait("first")
            .settings.log()
    )]
    ,
    // TRIAL 3: rabbit2 = wodewo
    ["trial", "PennController", PennController(
        image.defaults.settings.size(200, 200)
        ,
        // IMAGES
        newImage("competitor", "rabbit_3.png")
        ,
        newImage("target", "rabbit_3.png")
        ,
        newImage("f_arrow", "f_arrow.png")
        ,
        newImage("f_arrow2", "f_arrow.png")
        ,
        newImage("j_arrow", "j_arrow.png")
        ,
        newImage("white", "ffffff.png")
        ,
        
        newText("prompt", "Listen to the song of each bunny (indicated by an arrow). Once you've heard both, <b>select Bella's sister</b> by pressing the corresponding key.")
            .print()
        ,
        newText("press a key", "Press any key to continue.")
            .settings.color("red")
            .print()
        ,
        newKey("any", "")
            .wait()
        ,
        getText("press a key")
            .settings.color("white") // "Remove" the keypress instruction from screen
            .print()
        ,
        newCanvas("canvas", 450, 450)
            .settings.add(  0, 0, getImage("competitor"))
            .settings.add(250, 0, getImage("target"))
            .print()
        ,
        newTimer("familiarization", 500)
            .start() // We start the timer right away
            .wait() // And we wait for it to finish before proceeding
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow"))
            .print()
        ,
        newAudio("wodede", "wodede.wav")
            .play()
            .wait()
        ,
        newTimer("break_btwn_sent", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("white"))
            .settings.add(250, 250, getImage("j_arrow"))
            .print()
        ,
        newAudio("wodewo", "wodewo.wav")
            .play()
            .wait()
        ,
        newTimer("timer", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow2"))
            .print()
        ,
        newText("instruction", "\n\nPress the key corresponding to the rabbit that is part of Bella's family.")
            .print()
        ,
        newSelector("trial3")
            .settings.add(getImage("competitor"), getImage("target"))
            .settings.keys(            "F"   ,              "J"   )
        ,
        getSelector("trial3")
            .wait("first")
            .settings.log()
    )]
    ,
    // TRIAL 4: rabbit2 = fekofe
    ["trial", "PennController", PennController(
        image.defaults.settings.size(200, 200)
        ,
        // IMAGES
        newImage("competitor", "rabbit_4.png")
        ,
        newImage("target", "rabbit_4.png")
        ,
        newImage("f_arrow", "f_arrow.png")
        ,
        newImage("f_arrow2", "f_arrow.png")
        ,
        newImage("j_arrow", "j_arrow.png")
        ,
        newImage("white", "ffffff.png")
        ,
        
        newText("prompt", "Listen to the song of each bunny (indicated by an arrow). Once you've heard both, <b>select Bella's brother</b> by pressing the corresponding key.")
            .print()
        ,
        newText("press a key", "Press any key to continue.")
            .settings.color("red")
            .print()
        ,
        newKey("any", "")
            .wait()
        ,
        getText("press a key")
            .settings.color("white") // "Remove" the keypress instruction from screen
            .print()
        ,
        newCanvas("canvas", 450, 450)
            .settings.add(  0, 0, getImage("competitor"))
            .settings.add(250, 0, getImage("target"))
            .print()
        ,
        newTimer("familiarization", 500)
            .start() // We start the timer right away
            .wait() // And we wait for it to finish before proceeding
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow"))
            .print()
        ,
        newAudio("fekoko", "fekoko.wav")
            .play()
            .wait()
        ,
        newTimer("break_btwn_sent", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("white"))
            .settings.add(250, 250, getImage("j_arrow"))
            .print()
        ,
        newAudio("fekofe", "fekofe.wav")
            .play()
            .wait()
        ,
        newTimer("timer", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow2"))
            .print()
        ,
        newText("instruction", "\n\nPress the key corresponding to the rabbit that is part of Bella's family.")
            .print()
        ,
        newSelector("trial4")
            .settings.add(getImage("competitor"), getImage("target"))
            .settings.keys(            "F"   ,              "J"   )
        ,
        getSelector("trial4")
            .wait("first")
            .settings.log()
    )]
    ,
    // TRIAL 5: rabbit1 = dekode
    ["trial", "PennController", PennController(
        image.defaults.settings.size(200, 200)
        ,
        // IMAGES
        newImage("target", "rabbit_4.png")
        ,
        newImage("competitor", "rabbit_4.png")
        ,
        newImage("f_arrow", "f_arrow.png")
        ,
        newImage("f_arrow2", "f_arrow.png")
        ,
        newImage("j_arrow", "j_arrow.png")
        ,
        newImage("white", "ffffff.png")
        ,
        
        newText("prompt", "Listen to the song of each bunny (indicated by an arrow). Once you've heard both, <b>select Bella's brother</b> by pressing the corresponding key.")
            .print()
        ,
        newText("press a key", "Press any key to continue.")
            .settings.color("red")
            .print()
        ,
        newKey("any", "")
            .wait()
        ,
        getText("press a key")
            .settings.color("white") // "Remove" the keypress instruction from screen
            .print()
        ,
        newCanvas("canvas", 450, 450)
            .settings.add(  0, 0, getImage("target"))
            .settings.add(250, 0, getImage("competitor"))
            .print()
        ,
        newTimer("familiarization", 500)
            .start() // We start the timer right away
            .wait() // And we wait for it to finish before proceeding
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow"))
            .print()
        ,
        newAudio("dekode", "dekode.wav")
            .play()
            .wait()
        ,
        newTimer("break_btwn_sent", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("white"))
            .settings.add(250, 250, getImage("j_arrow"))
            .print()
        ,
        newAudio("dekoko", "dekoko.wav")
            .play()
            .wait()
        ,
        newTimer("timer", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow2"))
            .print()
        ,
        newText("instruction", "\n\nPress the key corresponding to the rabbit that is part of Bella's family.")
            .print()
        ,
        newSelector("trial5")
            .settings.add(getImage("target"), getImage("competitor"))
            .settings.keys(            "F"   ,              "J"   )
        ,
        getSelector("trial5")
            .wait("first")
            .settings.log()
    )]
    ,
    // TRIAL 6: rabbit1 = wofewo
    ["trial", "PennController", PennController(
        image.defaults.settings.size(200, 200)
        ,
        // IMAGES
        newImage("target", "rabbit_4.png")
        ,
        newImage("competitor", "rabbit_4.png")
        ,
        newImage("f_arrow", "f_arrow.png")
        ,
        newImage("f_arrow2", "f_arrow.png")
        ,
        newImage("j_arrow", "j_arrow.png")
        ,
        newImage("white", "ffffff.png")
        ,
        
        newText("prompt", "Listen to the song of each bunny (indicated by an arrow). Once you've heard both, <b>select Bella's brother</b> by pressing the corresponding key.")
            .print()
        ,
        newText("press a key", "Press any key to continue.")
            .settings.color("red")
            .print()
        ,
        newKey("any", "")
            .wait()
        ,
        getText("press a key")
            .settings.color("white") // "Remove" the keypress instruction from screen
            .print()
        ,
        newCanvas("canvas", 450, 450)
            .settings.add(  0, 0, getImage("target"))
            .settings.add(250, 0, getImage("competitor"))
            .print()
        ,
        newTimer("familiarization", 500)
            .start() // We start the timer right away
            .wait() // And we wait for it to finish before proceeding
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow"))
            .print()
        ,
        newAudio("wofewo", "wofewo.wav")
            .play()
            .wait()
        ,
        newTimer("break_btwn_sent", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("white"))
            .settings.add(250, 250, getImage("j_arrow"))
            .print()
        ,
        newAudio("wofefe", "wofefe.wav")
            .play()
            .wait()
        ,
        newTimer("timer", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow2"))
            .print()
        ,
        newText("instruction", "\n\nPress the key corresponding to the rabbit that is part of Bella's family.")
            .print()
        ,
        newSelector("trial6")
            .settings.add(getImage("target"), getImage("competitor"))
            .settings.keys(            "F"   ,              "J"   )
        ,
        getSelector("trial6")
            .wait("first")
            .settings.log()
    )]
    ,
    // TRIAL 7: rabbit2 = kofeko
    ["trial", "PennController", PennController(
        image.defaults.settings.size(200, 200)
        ,
        // IMAGES
        newImage("competitor", "rabbit_4.png")
        ,
        newImage("target", "rabbit_4.png")
        ,
        newImage("f_arrow", "f_arrow.png")
        ,
        newImage("f_arrow2", "f_arrow.png")
        ,
        newImage("j_arrow", "j_arrow.png")
        ,
        newImage("white", "ffffff.png")
        ,
        
        newText("prompt", "Listen to the song of each bunny (indicated by an arrow). Once you've heard both, <b>select Bella's brother</b> by pressing the corresponding key.")
            .print()
        ,
        newText("press a key", "Press any key to continue.")
            .settings.color("red")
            .print()
        ,
        newKey("any", "")
            .wait()
        ,
        getText("press a key")
            .settings.color("white") // "Remove" the keypress instruction from screen
            .print()
        ,
        newCanvas("canvas", 450, 450)
            .settings.add(  0, 0, getImage("competitor"))
            .settings.add(250, 0, getImage("target"))
            .print()
        ,
        newTimer("familiarization", 500)
            .start() // We start the timer right away
            .wait() // And we wait for it to finish before proceeding
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow"))
            .print()
        ,
        newAudio("kofefe", "kofefe.wav")
            .play()
            .wait()
        ,
        newTimer("break_btwn_sent", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("white"))
            .settings.add(250, 250, getImage("j_arrow"))
            .print()
        ,
        newAudio("kofeko", "kofeko.wav")
            .play()
            .wait()
        ,
        newTimer("timer", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow2"))
            .print()
        ,
        newText("instruction", "\n\nPress the key corresponding to the rabbit that is part of Bella's family.")
            .print()
        ,
        newSelector("trial7")
            .settings.add(getImage("competitor"), getImage("target"))
            .settings.keys(            "F"   ,              "J"   )
        ,
        getSelector("trial7")
            .wait("first")
            .settings.log()
    )]
    ,
    // TRIAL 8: rabbit1 = dewode
    ["trial", "PennController", PennController(
        image.defaults.settings.size(200, 200)
        ,
        // IMAGES
        newImage("target", "rabbit_4.png")
        ,
        newImage("competitor", "rabbit_4.png")
        ,
        newImage("f_arrow", "f_arrow.png")
        ,
        newImage("f_arrow2", "f_arrow.png")
        ,
        newImage("j_arrow", "j_arrow.png")
        ,
        newImage("white", "ffffff.png")
        ,
        
        newText("prompt", "Listen to the song of each bunny (indicated by an arrow). Once you've heard both, <b>select Bella's brother</b> by pressing the corresponding key.")
            .print()
        ,
        newText("press a key", "Press any key to continue.")
            .settings.color("red")
            .print()
        ,
        newKey("any", "")
            .wait()
        ,
        getText("press a key")
            .settings.color("white") // "Remove" the keypress instruction from screen
            .print()
        ,
        newCanvas("canvas", 450, 450)
            .settings.add(  0, 0, getImage("target"))
            .settings.add(250, 0, getImage("competitor"))
            .print()
        ,
        newTimer("familiarization", 500)
            .start() // We start the timer right away
            .wait() // And we wait for it to finish before proceeding
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow"))
            .print()
        ,
        newAudio("dewode", "dewode.wav")
            .play()
            .wait()
        ,
        newTimer("break_btwn_sent", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("white"))
            .settings.add(250, 250, getImage("j_arrow"))
            .print()
        ,
        newAudio("dewowo", "dewowo.wav")
            .play()
            .wait()
        ,
        newTimer("timer", 500)
            .start()
            .wait()
        ,
        getCanvas("canvas")
            .settings.add(  0, 250, getImage("f_arrow2"))
            .print()
        ,
        newText("instruction", "\n\nPress the key corresponding to the rabbit that is part of Bella's family.")
            .print()
        ,
        newSelector("trial8")
            .settings.add(getImage("target"), getImage("competitor"))
            .settings.keys(            "F"   ,              "J"   )
        ,
        getSelector("trial8")
            .wait("first")
            .settings.log()
    )]
    ,
    ["end", "PennController", PennController(
        // Preparing a warning message
        newText("warning", "Please enter some text before pressing Return.")
            .settings.bold()
            .settings.color("red")
        ,
        newText("ID", "Please enter your Prolific ID so you can receive credit for this task.")
            .settings.bold()
            .settings.color("red")
        ,
        newText("getID", "Please enter your Prolific ID and press Return.")
            .print()
        ,
        newTextInput("prolificID")
            .print()
            .wait(
                // The 'wait' only gets validated if the text is not "" (i.e. box is not void)
                getTextInput("prolificID").testNot.text("")
                    .failure( // We print a message in case of failure to comply
                        getText("ID").print()
                    ) // Keep track of the closing parentheses...
            ) // ... as the structure becomes more complicated
            .settings.log() 
        ,
        newText("native_lang", "Are you a native English speaker?")
            .print()
        ,
        newScale("native_English_speaker",    "yes", "no")
            .print()
            .wait()
            .settings.log()
        ,  
        newText("question", "How did you choose which rabbit belonged to Bella's family? Did you notice any patterns in the choices?")
            .settings.bold()
            .print()
        ,
        newText("instruct", "Type your response in the box below and press Return to complete the experiment.")
            .print()
        ,
        newTextInput("participant_feedback")
            .print()
            .wait(
                // The 'wait' only gets validated if the text is not "" (i.e. box is not void)
                getTextInput("participant_feedback").testNot.text("")
                    .failure( // We print a message in case of failure to comply
                        getText("warning").print()
                    ) // Keep track of the closing parentheses...
            ) // ... as the structure becomes more complicated
            .settings.log()
    )]
];